package kr.ac.hallym.prac14_network

class PageListModel {
    var articles: MutableList<ItemModel>? = null
}